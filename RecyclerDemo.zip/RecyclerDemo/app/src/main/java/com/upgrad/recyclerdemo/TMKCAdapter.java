package com.upgrad.recyclerdemo;


import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.widget.TextView;



public class TMKCAdapter extends RecyclerView.Adapter<TMKCAdapter.viewholder> {

    private  tmkc[] data;

    public TMKCAdapter(tmkc[] data) {
        this.data=data;
    }



    @Override
    public viewholder onCreateViewHolder(ViewGroup viewGroup, int i) {
        LayoutInflater inflater=LayoutInflater.from(viewGroup.getContext());
        View v=inflater.inflate(R.layout.character_row,viewGroup,false);
        viewholder viewholder= new viewholder(v);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(viewholder holder, int position) {
        holder.charname.setText(data[position].getChartext());
        holder.tagline.setText(data[position].getTagline());
        holder.charimage.setImageResource(data[position].getCharimage());
    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class viewholder extends RecyclerView.ViewHolder{
        TextView charname;
        TextView tagline;
        ImageView charimage;
        public viewholder( View itemView) {
            super(itemView);
            charname=(TextView) itemView.findViewById(R.id.chartext);
            tagline=(TextView) itemView.findViewById(R.id.tagline);
            charimage=(ImageView) itemView.findViewById(R.id.charimage);
        }
    }
}
