package com.upgrad.recyclerdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.GridLayout;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tmkc [] charlist= new tmkc []
        {
                new tmkc("Jethalal","Hello babita ji ",R.drawable.jethalal),
                new tmkc("Bagha","Vo jaisi jiski soch",R.drawable.bagha),
                new tmkc("Sodhi","Ohdi ehni himmat 😡😡",R.drawable.sodhi),
                new tmkc("daya","Tappu ke papa",R.drawable.daya),
                new tmkc("bhide","Society maintainance cheq😐",R.drawable.bhide)
        };
        RecyclerView recyclerView=(RecyclerView) findViewById(R.id.tmkc);
        TMKCAdapter adapter=new TMKCAdapter(charlist);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);
    }
}
