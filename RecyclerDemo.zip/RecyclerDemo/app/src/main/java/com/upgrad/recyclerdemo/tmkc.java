package com.upgrad.recyclerdemo;

public class tmkc {
    private String chartext;
    private String tagline;
    private int charimage;

    public tmkc(String chartext, String tagline, int charimage) {
        this.chartext = chartext;
        this.tagline = tagline;
        this.charimage = charimage;
    }

    public String getChartext() {
        return chartext;
    }

    public String getTagline() {
        return tagline;
    }

    public int getCharimage() {
        return charimage;
    }
}
